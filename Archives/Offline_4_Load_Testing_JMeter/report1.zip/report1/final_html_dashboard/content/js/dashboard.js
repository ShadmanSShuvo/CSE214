/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 60.4, "KoPercent": 39.6};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.604, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.84, 500, 1500, "/api/download/256"], "isController": false}, {"data": [0.98, 500, 1500, "/login"], "isController": false}, {"data": [0.16, 500, 1500, "/courses"], "isController": false}, {"data": [0.1, 500, 1500, "/notices"], "isController": false}, {"data": [0.94, 500, 1500, "/"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 250, 99, 39.6, 185.55200000000022, 5, 1874, 103.5, 409.8, 488.24999999999994, 1092.390000000001, 2.5188155521747455, 156.602929351002, 0.9627582100792923], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["/api/download/256", 50, 8, 16.0, 128.2, 30, 584, 86.0, 334.29999999999995, 475.4999999999994, 584.0, 0.5180273518441774, 132.75614429004352, 0.18616607956900125], "isController": false}, {"data": ["/login", 50, 1, 2.0, 22.1, 5, 401, 11.0, 27.39999999999999, 52.04999999999996, 401.0, 0.5201019399802361, 0.7847241184272117, 0.2224654782337338], "isController": false}, {"data": ["/courses", 50, 42, 84.0, 291.76000000000005, 177, 750, 280.0, 364.5, 543.0499999999992, 750.0, 0.518661438559366, 22.492381349712662, 0.20412164037053174], "isController": false}, {"data": ["/notices", 50, 45, 90.0, 365.18, 122, 1149, 368.0, 506.29999999999995, 584.6499999999996, 1149.0, 0.5178556632695335, 3.8019910902933134, 0.2002644947800149], "isController": false}, {"data": ["/", 50, 3, 6.0, 120.51999999999998, 21, 1874, 52.0, 140.1, 709.0999999999974, 1874.0, 0.5100323360501056, 1.2123229550253485, 0.17532361551722378], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["The operation lasted too long: It took 410 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 365 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 448 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 261 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 323 milliseconds, but should not have lasted longer than 200 milliseconds.", 3, 3.0303030303030303, 1.2], "isController": false}, {"data": ["The operation lasted too long: It took 257 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 2.0202020202020203, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 390 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 215 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 400 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 406 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 313 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 2.0202020202020203, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 256 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 268 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 405 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 391 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 289 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 230 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 509 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 421 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 397 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 458 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 484 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 246 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 317 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 401 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 2.0202020202020203, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 273 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 314 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 2.0202020202020203, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 440 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 638 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 241 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 224 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 244 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 558 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 360 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 298 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 411 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 1,149 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 295 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 369 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 221 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 202 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 324 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 279 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 350 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 2.0202020202020203, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 326 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 2.0202020202020203, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 285 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 2.0202020202020203, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 347 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 207 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 476 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 358 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 1,874 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 647 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 584 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 491 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 232 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 337 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 331 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 450 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 419 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 455 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 315 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 254 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 201 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 408 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 541 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 291 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 750 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 216 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 255 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 219 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 206 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 367 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 2.0202020202020203, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 297 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 328 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 508 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 432 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 310 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 387 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 277 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 2.0202020202020203, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 322 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 281 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 486 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 274 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 226 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 242 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 1,038 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.0101010101010102, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 287 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 2.0202020202020203, 0.8], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 250, 99, "The operation lasted too long: It took 323 milliseconds, but should not have lasted longer than 200 milliseconds.", 3, "The operation lasted too long: It took 257 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, "The operation lasted too long: It took 313 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, "The operation lasted too long: It took 401 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, "The operation lasted too long: It took 314 milliseconds, but should not have lasted longer than 200 milliseconds.", 2], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["/api/download/256", 50, 8, "The operation lasted too long: It took 216 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, "The operation lasted too long: It took 406 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, "The operation lasted too long: It took 558 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, "The operation lasted too long: It took 584 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, "The operation lasted too long: It took 408 milliseconds, but should not have lasted longer than 200 milliseconds.", 1], "isController": false}, {"data": ["/login", 50, 1, "The operation lasted too long: It took 401 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["/courses", 50, 42, "The operation lasted too long: It took 326 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, "The operation lasted too long: It took 285 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, "The operation lasted too long: It took 323 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, "The operation lasted too long: It took 257 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, "The operation lasted too long: It took 313 milliseconds, but should not have lasted longer than 200 milliseconds.", 2], "isController": false}, {"data": ["/notices", 50, 45, "The operation lasted too long: It took 314 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, "The operation lasted too long: It took 277 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, "The operation lasted too long: It took 410 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, "The operation lasted too long: It took 448 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, "The operation lasted too long: It took 347 milliseconds, but should not have lasted longer than 200 milliseconds.", 1], "isController": false}, {"data": ["/", 50, 3, "The operation lasted too long: It took 440 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, "The operation lasted too long: It took 1,874 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, "The operation lasted too long: It took 1,038 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
